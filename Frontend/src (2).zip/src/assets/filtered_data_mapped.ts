export const products = {
  "dairy": {
      "category": "Bestseller Milk Product",
      "name": "Buffalo milk",
      "price": "₹70",
      "description": "A divine embrace of rich creaminess, our Buffalo Milk is a heartfelt tribute to India's traditional kitchens. Every drop radiates the nurturing care of our buffaloes, making your dishes resound with authentic taste and warmth.",
      "number": "SDF01",
      "weight": "1Liter",
      "item": "Drink"
      
  },
  "id2": {
      "name": "Product B",
      "price": 150,
      "description": "This is product B.",
      "category": "Books"
  },
  "id3": {
      "name": "Product C",
      "price": 50,
      "description": "This is product C.",
      "category": "Groceries"
  }
};
