import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-shop-page',
  templateUrl: './main-shop-page.component.html',
  styleUrls: ['./main-shop-page.component.css']
})
export class MainShopPageComponent {
  

  
  constructor(
    private router: Router,
    private renderer: Renderer2, 
    private el: ElementRef,
    private route: ActivatedRoute  // <-- Inject ActivatedRoute here
  ) {}


  navigateToSingleProduct(divId: string) {
    this.router.navigate(['/singleshop'], { queryParams: { divId: divId } });
  }
  

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const filter = params['filter'];
      if (filter) {
        const event = {
          target: {
            value: filter
          }
        };
        this.filterProducts(event);
      }
    });
  }

  filterProducts(event: any) {
    const selectedValue = event.target.value;

    // Get all product elements
    const dairyProducts = this.el.nativeElement.querySelectorAll('#dairy');
    const sweetProducts = this.el.nativeElement.querySelectorAll('#sweet');

    // Initially hide all products
    dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'none'));
    sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'none'));

    // Show products based on the selected value
    if (selectedValue === 'dairy') {
        dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
    } else if (selectedValue === 'sweet') {
        sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
    } else if (selectedValue === 'all') {
        dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
        sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
    }
  }

}
