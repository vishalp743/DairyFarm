import { Component } from '@angular/core';

@Component({
  selector: 'app-single-shope-page',
  templateUrl: './single-shope-page.component.html',
  styleUrls: ['./single-shope-page.component.css']
})
export class SingleShopePageComponent {

}
