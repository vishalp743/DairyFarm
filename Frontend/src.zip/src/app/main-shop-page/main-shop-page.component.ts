import { Component } from '@angular/core';
import { Renderer2, ElementRef } from '@angular/core';
@Component({
  selector: 'app-main-shop-page',
  templateUrl: './main-shop-page.component.html',
  styleUrls: ['./main-shop-page.component.css']
})
export class MainShopPageComponent {
  constructor(private renderer: Renderer2, private el: ElementRef) {}

  filterProducts(event: any) {
    const selectedValue = event.target.value;

    // Get all product elements
    const dairyProducts = this.el.nativeElement.querySelectorAll('#dairy');
    const sweetProducts = this.el.nativeElement.querySelectorAll('#sweet');

    // Initially hide all products
    dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'none'));
    sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'none'));

    // Show products based on the selected value
    if (selectedValue === 'dairy') {
        dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
    } else if (selectedValue === 'sweet') {
        sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
    }else if (selectedValue === 'all') {
      dairyProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
      sweetProducts.forEach((product: any) => this.renderer.setStyle(product, 'display', 'block'));
  }
}
}
